// 重複したメールアドレスを探す（レビュー練習用）
export function findDuplicates(emails) {
  const dup = [];
  for (let i = 0; i < emails.length; i++) {
    for (let j = i + 1; j < emails.length; j++) {
      if (emails[i] === emails[j] && !dup.includes(emails[i])) dup.push(emails[i]);
    }
  }
  return dup;
}
