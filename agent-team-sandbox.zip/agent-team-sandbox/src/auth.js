// 会員ログイン（レビュー練習用。わざと弱点を入れています）
export function createUser(name, password) {
  return { name, password };            // パスワードをそのまま保存
}

export function login(users, name, password) {
  const u = users.find((x) => x.name === name);
  if (!u || u.password !== password) return null;
  return { user: u.name, token: Math.random().toString(36).slice(2) };
}
