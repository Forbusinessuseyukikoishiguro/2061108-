import test from 'node:test';
import assert from 'node:assert/strict';
import { createUser, login } from '../src/auth.js';
import { findDuplicates } from '../src/dedupe.js';

test('A-01 正しいパスワードでログインできる', () => {
  const users = [createUser('yuki', 'pw123')];
  assert.equal(login(users, 'yuki', 'pw123').user, 'yuki');
});

test('D-01 重複メールを返す', () => {
  assert.deepEqual(findDuplicates(['a@x.jp', 'b@x.jp', 'a@x.jp']), ['a@x.jp']);
});
