# 特典1：Claude Codeコマンド＆PowerShellからVS Code起動 シーン別チート集

うさうさ研修工房「複利エンジニアリング入門」受講生特典（2026年11月版）

## このチート集について

- 載せているコマンドと説明は、**公式資料（Claude Code公式、VS Code公式）に書かれているものだけ**です。
- 他のブログや解説記事にだけ載っているコマンドは、入れていません。
- 公式の最新の一覧は、各ページで確認してください。巻末の出典一覧にURLをまとめています。
- ページの全文は精読していません。検索結果に出た記載を根拠にしています。

---

## 1. PowerShellからVS Codeを起動する

### 1-1. いちばん使う流れ（コピペ用）

```powershell
mkdir fukuri-lab
cd fukuri-lab
code .
```

- `code .` は「いまのフォルダをVS Codeで開く」です。

### 1-2. codeコマンドの早見表（VS Code公式）

| やりたいこと | コマンド |
|---|---|
| いまのフォルダを開く | `code .` |
| 指定したフォルダを開く | `code C:\work\project` |
| 新しいウィンドウで開く | `code . -n`（`--new-window`） |
| 開いているウィンドウを再利用して開く | `code . -r`（`--reuse-window`） |
| ファイルの行・列へ移動して開く | `code -g app.py:42:5`（`--goto`） |
| 2つのファイルを比較する | `code --diff 旧.py 新.py` |
| バージョンを確認する | `code --version`（`-v`） |
| 使えるオプションの一覧を見る | `code --help` |

### 1-3. 動かないとき（VS Code公式）

| 症状 | 確認すること |
|---|---|
| `code` が認識されない | インストール後に、コンソールを閉じて開き直す（PATHの反映に再起動が必要） |
| 更新がうまくいかない | 公式はUser setupを推奨。System setupは、更新にも管理者権限が必要 |

---

## 2. Claude Codeのコマンド（ターミナル）

### 2-1. 導入と更新（Claude Code公式）

| やりたいこと | コマンド |
|---|---|
| インストール（PowerShell） | `irm https://claude.ai/install.ps1 \| iex` |
| 起動する | `claude` |
| 最新版へ更新 | `claude update` |
| MCPサーバーを設定 | `claude mcp` |

- 管理者として実行する必要はありません。
- WinGetでの導入方法もあります。コマンドは公式のセットアップページで確認してください。
- ネイティブ版は、バックグラウンドで自動更新されます。

### 2-2. 起動の仕方（Claude Code公式CLIリファレンス）

| やりたいこと | コマンド |
|---|---|
| 対話モードを開始 | `claude` |
| 最初の依頼つきで開始 | `claude "このプロジェクトを説明して"` |
| 1回だけ聞いて終了 | `claude -p "この関数を説明して"` |
| ファイルの中身を渡して聞く | `cat logs.txt \| claude -p "要点を説明して"` |
| 直近の会話を続ける | `claude -c`（`--continue`） |
| 会話をIDで再開 | `claude -r "セッションID" "続きをやって"` |
| 再開時に新しいIDにする（枝分かれ） | `claude --resume セッションID --fork-session` |
| 会話に名前をつけて開始 | `claude -n "my-feature-work"` |
| 作業フォルダを追加 | `claude --add-dir ../apps ../lib` |
| 出力をJSONにする（`-p`と併用） | `claude -p "質問" --output-format json` |
| エージェントの往復回数を制限 | `claude -p --max-turns 3 "質問"` |

### 2-3. セッション内のスラッシュコマンド

| コマンド | 使いどころ（公式資料の記載） |
|---|---|
| `/init` | CLAUDE.mdの雛形を作る |
| `/hooks` | 登録済みのHooksを見る。読み取り専用 |
| `/agents` | サブエージェントの管理。版によって、作成の画面があるかどうかが違う |

- 使えるスラッシュコマンドの全体は、公式のスラッシュコマンドのページで確認してください。

---

## 3. シーン別チート集

### 場面A：昨日の続きから始める

```powershell
cd C:\work\fukuri-lab
code .
claude -c
```

- `claude -c` は、このフォルダの直近の会話を続けます。
- 別の会話に戻したいときは `claude -r "セッションID"`。

### 場面B：初めてのプロジェクトで、まず全体をつかむ

```powershell
code .
claude "このプロジェクトを説明して"
```

セッション内で次を入力します。

```
/init
```

- `/init` で CLAUDE.md の雛形を作れます。
- CLAUDE.md は、セッション開始時に毎回読み込まれます。
- 古い指示や矛盾は、定期的に整理してください。

### 場面C：1回だけ聞いて終わる

```powershell
claude -p "この関数を説明して"
```

- `-p` は、答えを表示して終了します。
- 往復回数を制限するなら `claude -p --max-turns 3 "質問"`。

### 場面D：ファイルの中身を渡して聞く

```powershell
cat logs.txt | claude -p "要点を説明して"
```

### 場面E：結果をJSONで受け取る

```powershell
claude -p "質問" --output-format json
```

### 場面F：複数のフォルダをまたいで作業する

```powershell
claude --add-dir ../apps ../lib
```

### 場面G：会話を整理して再開する

```powershell
claude -n "my-feature-work"
claude -r "セッションID" "続きをやって"
claude --resume セッションID --fork-session
```

- 名前をつけた会話は、わかりやすく探せます。
- `--fork-session` は、再開するときに新しいIDにします。

### 場面H：サブエージェントを使う

- サブエージェントは、独自のコンテキストで動く専門のAIです。
- 置き場所は、プロジェクト用が `.claude/agents/`、個人用が `~/.claude/agents/` です。
- サブエージェントは、他のサブエージェントを起動できません。
- 作成方法は版で異なります。公式ページで確認してください。
  https://code.claude.com/docs/en/subagents

### 場面I：Hooksで自動処理を足す

- Hooksは、Claude Codeの決まった時点で動く、ユーザー定義のシェルコマンドです。
- `/hooks` のメニューは読み取り専用です。追加・変更・削除は、設定JSONを直接編集するか、Claudeに頼みます。
- 公式ガイドに、Windows（PowerShell）向けの通知の例があります。
  https://code.claude.com/docs/en/hooks-guide

### 場面J：インストールやエラーで困った

| 状況 | 見る場所 |
|---|---|
| コマンドの一覧を見たい | `code --help`（VS Code）／公式CLIリファレンス |
| インストールで詰まった | https://code.claude.com/docs/en/setup |
| VS Codeで使いたい | https://code.claude.com/docs/en/vs-code |
| 「&&が正しい区切りではない」と出る | PowerShellで、CMD用のコマンドを実行している可能性があります（公式セットアップの記載） |
| Git Bashが見つからない（Git導入済み） | settings.jsonの `CLAUDE_CODE_GIT_BASH_PATH` に場所を指定（公式セットアップの記載） |

---

## 4. 出典（すべて公式）

| 資料 | URL |
|---|---|
| Claude Code セットアップ | https://code.claude.com/docs/en/setup |
| Claude Code VS Code | https://code.claude.com/docs/en/vs-code |
| Claude Code CLIリファレンス | https://docs.claude.com/en/docs/claude-code/cli-reference |
| Claude Code CLAUDE.md（メモリ） | https://code.claude.com/docs/en/memory |
| Claude Code サブエージェント | https://code.claude.com/docs/en/subagents |
| Claude Code Hooksガイド | https://code.claude.com/docs/en/hooks-guide |
| VS Code コマンドライン | https://code.visualstudio.com/docs/editor/command-line |
| VS Code on Windows | https://code.visualstudio.com/docs/setup/windows |

※ CLIリファレンスは、検索結果に出た旧ドメインのURLを載せています。現行のページは公式ドキュメント内で確認してください。
